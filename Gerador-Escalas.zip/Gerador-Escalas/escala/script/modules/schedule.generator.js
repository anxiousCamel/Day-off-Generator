/** @module schedule/generator */
import { SHIFT_PRESETS, ROLE } from "./schedule.constraints.js";
import { buildMonthDays } from "./schedule.calendar.js";

/** Padrão circular 5x2 usando offset por índice do funcionário. */
function pattern5x2(offset = 0) { const base = ["W", "W", "W", "W", "W", "F", "F"]; return base.slice(offset).concat(base.slice(0, offset)); }

/** Gera matriz por funcionário (sem folgas especiais ainda). */
export function assignBaseWorkDays(employees, { year, month }) {
    const days = buildMonthDays(year, month);
    const schedules = {};
    employees.forEach((emp, idx) => {
        const p = pattern5x2(idx % 7);
        schedules[emp.nome] = days.map((_, i) => {
            const flag = p[i % 7];
            if (flag === "F") return "FOLGA";
            return { ...SHIFT_PRESETS[ROLE.PADRAO], nome: emp.nome, camisa: emp.camisa };
        });
    });
    return schedules;
}
