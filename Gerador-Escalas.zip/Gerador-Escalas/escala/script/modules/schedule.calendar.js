/** @module schedule/calendar */
const _cache = new Map();

/** Retorna metadados dos dias do mês (cacheado). */
export function buildMonthDays(year, month1to12) {
    const key = `${year}-${month1to12}`;
    if (_cache.has(key)) return _cache.get(key);

    const total = new Date(year, month1to12, 0).getDate();
    const days = [];
    for (let d = 1; d <= total; d++) {
        const weekday = new Date(year, month1to12 - 1, d).getDay(); // 0=Dom
        const weekIndex = Math.ceil(d / 7);
        days.push({ day: d, weekday, weekIndex });
    }
    _cache.set(key, days);
    return days;
}
export const isSaturday = (wd) => wd === 6;
export const isSunday = (wd) => wd === 0;
