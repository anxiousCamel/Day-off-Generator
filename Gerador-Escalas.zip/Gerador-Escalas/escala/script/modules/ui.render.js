/** @module ui/render */
export function renderHeader(year, month, totalDays) {
    const thead = document.getElementById("theadEscala");
    thead.innerHTML = "";

    const trWeeks = document.createElement("tr");
    const thW = document.createElement("th"); thW.textContent = "Semanas"; trWeeks.appendChild(thW);
    let cur = 1; while (cur <= totalDays) { const span = Math.min(7, totalDays - cur + 1); const th = document.createElement("th"); th.colSpan = span; th.textContent = `Semana ${Math.ceil(cur / 7)}`; trWeeks.appendChild(th); cur += span; }

    const trDays = document.createElement("tr");
    const thD = document.createElement("th"); thD.textContent = "Dias"; trDays.appendChild(thD);
    for (let d = 1; d <= totalDays; d++) { const th = document.createElement("th"); th.textContent = `${d}/${month}`; trDays.appendChild(th); }

    const trNames = document.createElement("tr");
    const thN = document.createElement("th"); thN.textContent = "Funcionários"; trNames.appendChild(thN);
    for (let d = 1; d <= totalDays; d++) { trNames.appendChild(document.createElement("th")); }

    thead.appendChild(trWeeks); thead.appendChild(trDays); thead.appendChild(trNames);
}

export function renderScheduleBody(perEmp) {
    const tbody = document.getElementById("funcionarios-escala");
    tbody.innerHTML = "";
    for (const [name, days] of Object.entries(perEmp)) {
        const tr = document.createElement("tr");
        const tdN = document.createElement("td"); tdN.textContent = name; tr.appendChild(tdN);
        days.forEach(cell => {
            const td = document.createElement("td");
            if (cell === "FOLGA") { td.textContent = "FOLGA"; td.style.backgroundColor = "lightcoral"; }
            else { td.textContent = cell.label; td.title = cell.role || "PADRÃO"; td.style.backgroundColor = "whitesmoke"; }
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    }
}
