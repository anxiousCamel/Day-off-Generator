/** @file main.js */
import { buildMonthDays } from "./modules/schedule.calendar.js";
import { assignBaseWorkDays } from "./modules/schedule.generator.js";
import {
    ensureSaturdayRule,
    injectGreyCoverage,
    enforceMaxSixStreak,
    ensureNoEmptyStore,
    ensureMonthlySaturdayOffAnd2Consecutive
} from "./modules/schedule.repair.js";
import { renderHeader, renderScheduleBody } from "./modules/ui.render.js";

/** Carrega funcionários do localStorage. */
function loadEmployees() {
    try {
        const raw = localStorage.getItem("funcionarios");
        const arr = JSON.parse(raw);
        return Array.isArray(arr) ? arr : [];
    } catch { return []; }
}

/** Função pública: gera e renderiza a escala do mês selecionado. */
function generateSchedule() {
    const mesInput = document.getElementById("mes");
    if (!mesInput || !mesInput.value) { alert("Selecione um mês (YYYY-MM)."); return; }

    const [year, month] = mesInput.value.split("-").map(Number);
    const employees = loadEmployees();
    const days = buildMonthDays(year, month);

    // base 5x2
    const perEmp = assignBaseWorkDays(employees, { year, month });

    // reparos de regra
    ensureSaturdayRule(employees, perEmp, { year, month });
    injectGreyCoverage(employees, perEmp, { year, month });
    enforceMaxSixStreak(perEmp);
    ensureNoEmptyStore(employees, perEmp, { year, month });
    ensureMonthlySaturdayOffAnd2Consecutive(employees, perEmp, { year, month });

    // render
    renderHeader(year, month, days.length);
    renderScheduleBody(perEmp);
}

/** expõe para o controller chamar (JS puro) */
window.__schedule_generate = generateSchedule;
export { generateSchedule };

/** inicia controladores (botões + lista de funcionários) */
import { initButtonsController } from "./controllers/buttons.controller.js";
import { initEmployeesController } from "./controllers/employees.controller.js";
initButtonsController();
initEmployeesController();
